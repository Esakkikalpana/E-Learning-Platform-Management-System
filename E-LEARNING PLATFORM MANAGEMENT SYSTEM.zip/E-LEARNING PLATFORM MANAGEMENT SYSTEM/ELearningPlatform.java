import java.util.*;

// Binary Search Tree for searching students
class BSTNode {
    String studentName;
    int studentID;
    BSTNode left, right;

    public BSTNode(String name, int id) {
        this.studentName = name;
        this.studentID = id;
        this.left = this.right = null;
    }
}

class BST {
    private BSTNode root;

    public void insert(String name, int id) {
        root = insertRec(root, name, id);
    }

    private BSTNode insertRec(BSTNode root, String name, int id) {
        if (root == null) return new BSTNode(name, id);
        if (id < root.studentID) root.left = insertRec(root.left, name, id);
        else root.right = insertRec(root.right, name, id);
        return root;
    }

    public BSTNode search(int id) {
        return searchRec(root, id);
    }

    private BSTNode searchRec(BSTNode root, int id) {
        if (root == null || root.studentID == id) return root;
        return id < root.studentID ? searchRec(root.left, id) : searchRec(root.right, id);
    }
}

// Main E-Learning Platform Management System
public class ELearningPlatform {
    private ArrayList<String> courses = new ArrayList<>();
    private LinkedList<String> enrolledStudents = new LinkedList<>();
    private HashMap<Integer, String> studentRecords = new HashMap<>();
    private BST studentTree = new BST();
    
    public void addCourse(String course) {
        courses.add(course);
        System.out.println("Course added: " + course);
    }
    
    public void enrollStudent(String name, int id) {
        enrolledStudents.add(name);
        studentRecords.put(id, name);
        studentTree.insert(name, id);
        System.out.println("Student enrolled: " + name + " (ID: " + id + ")");
    }
    
    public void displayCourses() {
        System.out.println("Available Courses: " + courses);
    }
    
    public void displayEnrolledStudents() {
        System.out.println("Enrolled Students: " + enrolledStudents);
    }
    
    public void searchStudentByID(int id) {
        BSTNode result = studentTree.search(id);
        if (result != null) System.out.println("Student found: " + result.studentName + " (ID: " + result.studentID + ")");
        else System.out.println("Student not found!");
    }
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ELearningPlatform platform = new ELearningPlatform();
        
        while (true) {
            System.out.println("\n1. Add Course\n2. Enroll Student\n3. Display Courses\n4. Display Enrolled Students\n5. Search Student by ID\n6. Exit");
            System.out.print("Enter choice: ");
            int choice = sc.nextInt();
            sc.nextLine(); 
            
            switch (choice) {
                case 1:
                    System.out.print("Enter course name: ");
                    String course = sc.nextLine();
                    platform.addCourse(course);
                    break;
                case 2:
                    System.out.print("Enter student name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter student ID: ");
                    int id = sc.nextInt();
                    platform.enrollStudent(name, id);
                    break;
                case 3:
                    platform.displayCourses();
                    break;
                case 4:
                    platform.displayEnrolledStudents();
                    break;
                case 5:
                    System.out.print("Enter student ID to search: ");
                    int searchID = sc.nextInt();
                    platform.searchStudentByID(searchID);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}
